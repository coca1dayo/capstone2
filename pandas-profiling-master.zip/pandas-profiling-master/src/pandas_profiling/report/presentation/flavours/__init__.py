from pandas_profiling.report.presentation.flavours.flavours import (
    HTMLReport,
    QtReport,
    WidgetReport,
)
